package net.pigmanbruh.vineboom;

import net.fabricmc.api.ClientModInitializer;

public class MainClient implements ClientModInitializer {
	@Override
	public void onInitializeClient() {	

	}	

}